package abc;

/**
 * ALU operations: Addition, Subtraction, Multiplication, and Division
 */
public enum Operator {
     ADD,
     SUB,
     MULT,
     DIV
}